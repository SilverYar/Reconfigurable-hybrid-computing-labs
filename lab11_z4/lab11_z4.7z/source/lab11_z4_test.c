#define N 4
#include <stdio.h>

int main() {
  int a_a[N], a_e[N], b[N], c[N], d[N];
  int i, pass = 1;
  for (i = N-1; i >= 0 ; i--) {
    b[i] = N - i * i;
    c[i] = i;
    d[i] = i % 2;
    a_e[i] = d[i] ? b[i] + c[i] : b[i] - c[i];
  }
  
  foo(a_a, b, c, d);
  
  fprintf(stdout, "Expected \t  \t Actual\n");
  fprintf(stdout, "-------- \t  \t ------\n");
  for (i = 0; i < N && pass; i++) {
    fprintf(stdout, "e[%2d]:%d \t==\t a[%2d]:%d\n", i, a_e[i], i, a_a[i]);
    if (a_a[i] != a_e[i])
      pass = 0;
  }

  if (pass) {
		fprintf(stdout, "----------Pass!------------\n");
		return 0;
	} else {
		fprintf(stderr, "----------Fail!------------\n");
		return 1;
	}
}
