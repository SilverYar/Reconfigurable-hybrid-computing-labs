# 1 "D:/SPbPU/HLS/lab11_z4/source/lab11_z4.c"
# 1 "D:/SPbPU/HLS/lab11_z4/source/lab11_z4.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 147 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "D:/SPbPU/HLS/lab11_z4/source/lab11_z4.c" 2

void foo(int a[4], int b[4], int c[4], int d[4]) {
  int i;
  Add: for (i = 4 -1; i >= 0; i--) {
    if (d[i])
      a[i] = b[i] + c[i];
  }
  Sub: for (i = 4 -1; i >= 0; i--) {
    if (!d[i])
      a[i] = b[i] - c[i];
  }
}
