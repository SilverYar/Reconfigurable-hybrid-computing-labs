// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
# 1 "D:/SPbPU/HLS/lab8_z2/source/lab8_z2_m.c"
# 1 "D:/SPbPU/HLS/lab8_z2/source/lab8_z2_m.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 147 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "D:/SPbPU/HLS/lab8_z2/source/lab8_z2_m.c" 2


void foo(int data_in[32], int scale, int data_out[32]) {
  int temp1[32], temp2[32], temp3[32], temp4[32];
  Loop1: for (int i = 0; i < 32; i++) {
    temp1[i] = data_in[i] * scale;
    temp2[i] = data_in[i] >> scale;
  }
  Loop2: for (int j = 0; j < 32; j++) {
    temp3[j] = temp1[j] + 123;
    temp4[j] = temp2[j];
  }
  Loop3: for (int k = 0; k < 32; k++) {
    data_out[k] = temp4[k] + temp3[k];
  }
}
