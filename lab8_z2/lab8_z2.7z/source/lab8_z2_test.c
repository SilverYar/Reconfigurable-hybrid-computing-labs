#include <stdio.h>
#define N 32

void generate_data (int scale, int data_in[N], int data_out[N]) {
  for (int i = 0; i < N; i++) {
    data_in[i] = i;
    data_out[i] = (data_in[i] * scale + 123) + (data_in[i] >> scale);
  }
}

int compare_arrays (int actual[N], int expected[N]) {
  for (int i = 0; i < N; ++i) {
    if (actual[i] != expected[i]) {
      fprintf(stdout, "Expected[%d]:%d != Actual[%d]:%d\n", i, expected[i], i, actual[i]);
      return 0;
    }
  }
  return 1;
}

int main () {
  int pass = 1;
  int scale, data_in[N];
  int data_out[N];
  int expected_out[N];
  
  for (int i = 1; i < 4 && pass; ++i ) {
    scale = i;
    generate_data(scale, data_in, expected_out);
    
    foo(data_in, scale, data_out);
    
    if(!compare_arrays(data_out, expected_out)) {
      pass = 0;
    }
  }
  
  if(pass) {
    fprintf(stdout, "----------Pass!------------\n");
    return 0;
  } else {
    fprintf(stderr, "----------Fail!------------\n");
    return 1;
  }
}
