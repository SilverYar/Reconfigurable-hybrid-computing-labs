#define N 32

void foo(int data_in[N], int scale, int data_out[N]) {
  int temp1[N], temp2[N], temp3[N];
  Loop1: for(int i = 0; i < N; i++) {
    temp1[i] = data_in[i] * scale;
    temp2[i] = data_in[i] >> scale;
  }
  Loop2: for(int j = 0; j < N; j++) {
    temp3[j] = temp1[j] + 123;
  }
  Loop3: for(int k = 0; k < N; k++) {
    data_out[k] = temp2[k] + temp3[k];
  }
}
