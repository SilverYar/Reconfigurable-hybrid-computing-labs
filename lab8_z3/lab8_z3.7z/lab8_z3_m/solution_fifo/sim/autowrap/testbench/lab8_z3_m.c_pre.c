# 1 "D:/SPbPU/HLS/lab8_z3/source/lab8_z3_m.c"
# 1 "D:/SPbPU/HLS/lab8_z3/source/lab8_z3_m.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 147 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "D:/SPbPU/HLS/lab8_z3/source/lab8_z3_m.c" 2


void foo(int data_in[32], int data_out[32], int sel) {
  int temp1[32], temp2[32];
  Loop1: for(int i = 0; i < 32; i++) {
    if (sel) {
      temp1[i] = data_in[i] * 123;
    } else {
      temp1[i] = data_in[i] * 321;
    }
    Loop2: for(int j = 0; j < 32; j++) {
      temp2[j] = data_in[j];
    }
    Loop3: for(int k = 0; k < 32; k++) {
      data_out[k] = temp1[k] * temp2[k];
    }
  }
}
