#include <stdio.h>
#define N 32

void generate_data (int data_in[N], int data_out[N], int sel) {
  int tmp;
  if (sel) tmp = 123;
  else     tmp = 321;
  for (int i = 0; i < N; i++) {
    data_in[i] = i;
    data_out[i] = data_in[i] * tmp * data_in[i];
  }
}

int compare_arrays (int actual[N], int expected[N]) {
  for (int i = 0; i < N; ++i) {
    if (actual[i] != expected[i]) {
      fprintf(stdout, "Expected[%d]:%d != Actual[%d]:%d\n", i, expected[i], i, actual[i]);
      return 0;
    }
  }
  return 1;
}

int main () {
  int pass = 1;
  int sel, data_in[N];
  int data_out[N];
  int expected_out[N];
  
  for (int i = 0; i <= 1 && pass; ++i ) {
    sel = i;
    generate_data(data_in, expected_out, sel);
    
    foo(data_in, data_out, sel);
    
    if(!compare_arrays(data_out, expected_out)) {
      pass = 0;
    }
  }
  
  if(pass) {
    fprintf(stdout, "----------Pass!------------\n");
    return 0;
  } else {
    fprintf(stderr, "----------Fail!------------\n");
    return 1;
  }
}
