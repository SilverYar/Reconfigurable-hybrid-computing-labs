// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
# 1 "D:/SPbPU/HLS/lab8_z1/source/lab8_z1_m.c"
# 1 "D:/SPbPU/HLS/lab8_z1/source/lab8_z1_m.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 147 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "D:/SPbPU/HLS/lab8_z1/source/lab8_z1_m.c" 2


void Split(int in[32], int out1[32], int out2[32]) {

  L1: for (int i = 0; i < 32; i++) {
    out1[i] = in[i];
    out2[i] = in[i];
  }
}

void foo(int data_in[32], int scale, int data_out1[32], int data_out2[32]) {
  int temp1[32], temp2[32], temp3[32];
  Loop1: for (int i = 0; i < 32; i++) {
    temp1 [ i ] = data_in [ i ] * scale;
  }
  Split(temp1, temp2, temp3);
  Loop2: for (int j = 0; j < 32; j++) {
    data_out1[j] = temp2[j] * 123;
  }
  Loop3: for (int k = 0; k < 32; k++) {
    data_out2[k] = temp3[k] * 456;
  }
}
