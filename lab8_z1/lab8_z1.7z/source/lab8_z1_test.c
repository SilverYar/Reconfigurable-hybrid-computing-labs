#include <stdio.h>
#define N 32

void generate_data (int scale, int data_in[N], int data_out1[N], int data_out2[N]) {
  int temp1;
  for (int i = 0; i < N; i++) {
    data_in[i] = i;
    temp1 = i * scale;
    data_out1[i] = temp1 * 123;
    data_out2[i] = temp1 * 456;
  }
}

int compare_arrays (int actual[N], int expected[N]) {
  for (int i = 0; i < N; ++i) {
    if (actual[i] != expected[i]) {
      fprintf(stdout, "Expected[%d]:%d != Actual[%d]:%d\n", i, expected[i], i, actual[i]);
      return 0;
    }
  }
  return 1;
}

int main () {
  int pass = 1;
  int scale, data_in[N];
  int data_out1[N], data_out2[N];
  int expected_out1[N], expected_out2[N];
  
  for (int i = 1; i < 4 && pass; ++i ) {
    scale = i;
    generate_data(scale, data_in, expected_out1, expected_out2);
    
    foo(data_in, scale, data_out1, data_out2);
    
    if(!compare_arrays(data_out1, expected_out1)
    || !compare_arrays(data_out2, expected_out2)) {
      pass = 0;
    }
  }
  
  if(pass) {
    fprintf(stdout, "----------Pass!------------\n");
    return 0;
  } else {
    fprintf(stderr, "----------Fail!------------\n");
    return 1;
  }
}
