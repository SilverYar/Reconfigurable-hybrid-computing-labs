#define N 32

void Split(int in[N], int out1[N], int out2[N]) {
  // Duplicated data
  L1: for (int i = 0; i < N; i++) {
    out1[i] = in[i];
    out2[i] = in[i];
  }
}

void foo(int data_in[N], int scale, int data_out1[N], int data_out2[N]) {
  int temp1[N], temp2[N], temp3[N];
  Loop1: for (int i = 0; i < N; i++) {
    temp1[i] = data_in[i] * scale;
  }
  Split(temp1, temp2, temp3);
  Loop2: for (int j = 0; j < N; j++) {
    data_out1[j] = temp2[j] * 123;
  }
  Loop3: for (int k = 0; k < N; k++) {
    data_out2[k] = temp3[k] * 456;
  }
}
